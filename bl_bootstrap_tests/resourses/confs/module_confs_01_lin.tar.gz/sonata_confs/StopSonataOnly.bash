#!/bin/bash

w_dog_dir=/usr/bin/dolphin/WatchDogServer
conf_dir=/usr/bin/dolphin/trassa_confs/main_trassa.xml
${w_dog_dir} --stop
