#! /bin/bash
cd /usr/bin/dolphin/
TMP=/tmp 
./WatchDogServer --stop
