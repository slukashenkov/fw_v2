#! /bin/bash

w_dog_srv=/usr/bin/dolphin/WatchDogServer
conf_file=/usr/bin/dolphin/install_confs/mainTestUDP_only.xml

cd /usr/bin/dolphin;
TMP=/tmp; 
${w_dog_srv} --start --conf=${conf_file} 
