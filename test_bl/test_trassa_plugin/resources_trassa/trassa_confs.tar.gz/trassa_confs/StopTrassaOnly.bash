#!/bin/bash

path_to_wdog=/usr/bin/dolphin/WatchDogServer 
${path_to_wdog} --stop
