#!/bin/bash

main_xml_path=/usr/bin/dolphin/trassa_confs/main_trassa.xml
./WatchDogServer --start --conf=${main_xml_path} >/dev/null
